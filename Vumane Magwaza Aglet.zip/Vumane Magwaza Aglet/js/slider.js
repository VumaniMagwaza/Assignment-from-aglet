const slider = document.querySelector(".video-slider");
const btnLeft = document.querySelector(".slider-btn.left");
const btnRight = document.querySelector(".slider-btn.right");

btnLeft.addEventListener("click", () => {
  slider.scrollBy({ left: -slider.offsetWidth, behavior: "smooth" });
});

btnRight.addEventListener("click", () => {
  slider.scrollBy({ left: slider.offsetWidth, behavior: "smooth" });
});
